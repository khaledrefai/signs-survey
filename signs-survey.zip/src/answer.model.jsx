
export class Answer{
 constructor(imageId,imageName,imageAnswer,userAnswer ,totalTimeSec , mark){
        this.imageId=imageId;
        this.imageName=imageName;
        this.imageAnswer = imageAnswer;
        this.userAnswer = userAnswer;
        this.totalTimeSec = totalTimeSec;
        this.mark = mark;
 } 
}
